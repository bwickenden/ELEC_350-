#include "mbed.h"
#include "SPI.h"
#include "usart.c"
#include "lcd.h"
#include "lcd.c"
#include "interrupt.h"
#include "interrupt.c"
#include "LED.h"
#include "LED.c"
#include "ADC.h"

int SC = 0x00; // Score
int HSC=0x00; // High score
int r =0x07; //Variable for LED to stop on 
unsigned int i;
int Button = 0; //User button 
extern int d; // Difficulty 
extern int st; // State in SPI seq

int main (void)
{
	SystemInit(); //Sync clock
	SystemCoreClockUpdate(); //Sync Clock
	init_interrupt(); // initialise interrupt timer seq
	init_Nucleo_LED();
	init_LED();		//initialise LED sequence using spi
	initLCD();		// initialise LCD
	init_USART(); // Initialise USART
//	init_ADC_DAC(); //initalise ADC/DAC
	
	
	// Set up for Messages to be sent to LCD
	char msg[]="Stop LED on "; // Stop LED ON
	char Score[]="Score"; // Score
	char High_Score[]="High Score";// High Score

		
		while(1) //Set up loop
{
		cmdLCD4(LCD_LINE1); // Select line 1
		for (i=0 ;i<5; i++) putLCD(Score[i]); // Display score on line 1
		
		cmdLCD4(LCD_LINE1+6); // Select line 1 shifted by 6 
		LCD_var(SC); // Display Score variable 

		cmdLCD4(LCD_LINE2);		//Select line 2
		for (i=0 ;i<10; i++) putLCD(High_Score[i]); //Display 
	
	
		cmdLCD4(LCD_LINE2+11); // Select line 2 Shifted 11 
		LCD_var(HSC); //Display High score
		
		for (i=0 ;i<12; i++) send_usart(msg[i]); // Send Variable r using usart
		tx_hex_byte(r);
		for(i=0; i<100000; i++);
		LED_1();
		
}
	
	
}

	
