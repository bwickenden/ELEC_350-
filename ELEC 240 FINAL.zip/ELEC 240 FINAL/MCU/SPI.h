
#ifndef _SPI_H_
#define _SPI_H_
#include <stm32f4xx.h>

void init_LED(void);
void LED_1(void);
void Button_Press (void);



#endif

