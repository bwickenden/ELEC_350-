#include "SPI.h"
#include "mbed.h"
#include "lcd.h"
#include "usart.h"


extern int Button; //User button to stop seq on correct LED
int d  =200; //Variable to control speed
int st =0; //State in seq
extern  int SC; // Score
extern int HSC ; // Hight Score
extern int r;
extern unsigned int i;
 
 

SPI spi(PA_7, PA_6, PA_5);      // Ordered as: mosi, miso, sclk could use forth parameter ssel
DigitalOut cs(PC_6);            // Chip Select for outputs to control LEDs GPIO_2

int32_t read_switches(void);    //Read 4 Sliding switches on FPGA (Simulating OPTO-Switches from Motor(s)


  
void init_LED(void) {
	
    cs = 1;                     // Chip must be deselected, Chip Select is active LOW
    spi.format(8,0);            // Setup the DATA frame SPI for 16 bit wide word, Clock Polarity 0 and Clock Phase 0 (0)
    spi.frequency(1000000);     // 1MHz clock rate

		printf("TEST\n\r");
}
   void LED_1(void)                // LED FUCNTION FOR SHIFTING THE ROW OF LEDs 
    {
        read_switches();
			
     
        for (uint32_t i=128;i>=1;)
        {
					if (i ==128)
						{
								cs = 0;             //Select the device by seting chip select LOW
								spi.write(0);				//Send the command
								spi.write(i);				//Send the data - ignore the return data
								cs = 1;             //De-Select the device by seting chip select HIGH
								wait_ms(d);
								i = i/2;
								st = 1;							//State 1
								Button_Press();			// Check for button press
						}
						if (i == 64)
						{
								cs = 0;             //Select the device by seting chip select LOW
								spi.write(0);				//Send the command
								spi.write(i);				//Send the data - ignore the return data
								cs = 1;             //De-Select the device by seting chip select HIGH
								wait_ms(d);
								i= i/2;
								st = 2;							//State 2 
								Button_Press();			//Check for button press
						}
						
						if (i== 32)
						{
								cs = 0;             //Select the device by seting chip select LOW
								spi.write(0);				//Send the command
								spi.write(i);				//Send the data - ignore the return data
								cs = 1;             //De-Select the device by seting chip select HIGH
								wait_ms(d);
								i= i/2;
								st = 3;							//State 3 
								Button_Press();			//Check for button press
						}
						
						if (i== 16)
						{
								cs = 0;             //Select the device by seting chip select LOW
								spi.write(0);				//Send the command
								spi.write(i);				//Send the data - ignore the return data
								cs = 1;             //De-Select the device by seting chip select HIGH
								wait_ms(d);
								i= i/2;
								st = 4;							//State 4
								Button_Press();			// Check for button press
						}
						if (i== 8)
						{
								cs = 0;             //Select the device by seting chip select LOW
								spi.write(0);				//Send the command
								spi.write(i);				//Send the data - ignore the return data
								cs = 1;             //De-Select the device by seting chip select HIGH
								wait_ms(d);
								i= i/2;
								st = 5;							// State 5
								Button_Press();			//	Check for button press
						}
						if (i== 4)
						{
								cs = 0;             //Select the device by seting chip select LOW
								spi.write(0);				//Send the command
								spi.write(i);				//Send the data - ignore the return data
								cs = 1;             //De-Select the device by seting chip select HIGH
								wait_ms(d);
								i= i/2;
								st = 6;							// State 6 
								Button_Press();			// Check for button press
						}
						
						if (i== 2)
						{
								cs = 0;             //Select the device by seting chip select LOW
								spi.write(0);				//Send the command
								spi.write(i);				//Send the data - ignore the return data
								cs = 1;             //De-Select the device by seting chip select HIGH
								wait_ms(d);
								i= i/2;
								st = 7;							// State 7 
								Button_Press();			// Check for button press
						}
				
						if (i== 1)
						{
								cs = 0;             //Select the device by seting chip select LOW
								spi.write(0);				//Send the command
								spi.write(i);				//Send the data - ignore the return data
								cs = 1;             //De-Select the device by seting chip select HIGH
								wait_ms(d);
								i= 128;
								st = 9;							// State 9
								Button_Press();			// Check for button press
						}
						
							
        }
				
    }


	//Function to read back the state of the switches
int read_switches(void){
    int sw_val = 0;
    cs = 0;				//Select the device by seting chip select LOW
    spi.write(0);	//Command
    sw_val = spi.write(0x01) & 0x0F; // Just want to read back lower 4bit nibble
    cs = 1 ;			//De-select the device by seting chip select HIGH
   // if (sw_val&(1<<0)){ printf("Switch 0 :"); }
   // if (sw_val&(1<<1)){ printf("Switch 1 :"); }
    //if (sw_val&(1<<2)){ printf("Switch 2 :"); }
   // if (sw_val&(1<<3)){ printf("Switch 3 :"); }
    if (sw_val>0)     { printf("\r\n");       }
    return sw_val;    
}

void Button_Press (void)
{
	
	// Set up for LCD messages
	char End_1[]="GAME OVER";
	char High_Score[]="High Score";
	char Score[]="Score";
	char clear[]="          ";
	
	// function for user button press to stop LED
	Button = (GPIOC -> IDR >> 13) & 1;
		if (Button == 1)
		{
			lcd_delayus(250000);
				
			if  (r == st)
				{
				d++; // Increase speed control
				SC++; // Increase score
			
				cmdLCD4(LCD_LINE1);
				for (i=0 ;i<5; i++) putLCD(Score[i]); // Display score
		
				cmdLCD4(LCD_LINE1+6);
				LCD_var(SC);

				cmdLCD4(LCD_LINE2);		
				for (i=0 ;i<10; i++) putLCD(High_Score[i]); //Display high score
	
	
				cmdLCD4(LCD_LINE2+11);
				LCD_var(HSC);
					
				
				}
			
			else
			{
				if (SC >= HSC) // Update high score if score if larger
				{
					HSC = SC; 
				}
				
				SC=0; // reset score to zero
				cmdLCD4(LCD_LINE1); //Select line 1 LCD
				for (i=0 ;i<9; i++) putLCD(End_1[i]); // Display Game over 
				
				cmdLCD4(LCD_LINE2);		
				for (i=0 ;i<10; i++) putLCD(High_Score[i]); //Display High score 2nd line
	
				cmdLCD4(LCD_LINE2+11); //Select 2nd line 
				LCD_var(HSC); // Display high score
				
				lcd_delayus(250000);
				
				cmdLCD4(LCD_LINE1); //Select line 1 LCD
				
				for (i=0 ;i<10; i++) putLCD(clear[i]); // Clear display
				
				for(i=0; i<10000; i++);
				
				cmdLCD4(LCD_LINE1);
				for (i=0 ;i<5; i++) putLCD(Score[i]); // Display score
		
				cmdLCD4(LCD_LINE1+6);
				LCD_var(SC);
			
			}
		}
}

