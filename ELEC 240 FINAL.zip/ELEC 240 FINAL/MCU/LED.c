#include <stm32f4xx.h>
#include "LED.h"

void init_Nucleo_LED(void)					// NUCLEO LED
{
	
	
	
	GPIOB->MODER |= GPIO_MODER_MODE7_0;
	GPIOB->OTYPER &= ~(GPIO_OTYPER_OT_7);
	
	GPIOB->BSRR = (1<<7); // Blue LED ON
	

}
