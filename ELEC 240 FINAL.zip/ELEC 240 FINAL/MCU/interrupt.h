
#ifndef _INTERRUPT_H_
#define _INTERRUPT_H_
#include <stm32f4xx.h>


void init_interrupt(void);
void TIM2_IRQHandler(void);



#endif

